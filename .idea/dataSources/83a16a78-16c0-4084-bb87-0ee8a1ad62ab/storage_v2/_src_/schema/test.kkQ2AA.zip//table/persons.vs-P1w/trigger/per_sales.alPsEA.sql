create definer = root@localhost trigger per_sales
    after insert
    on persons
    for each row
    insert into sales values(new.name,new.num);

