create
    definer = root@localhost function count_sch() returns int reads sql data
    return (select count(*) from sch);

